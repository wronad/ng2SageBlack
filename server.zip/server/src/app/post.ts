// 3 export class Post {
export interface Post {
    userId: number;
    id?: number; // id is optional
    title: string;
    body: string;
}