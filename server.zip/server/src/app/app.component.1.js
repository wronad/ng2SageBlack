"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
// import svc
var post_service_1 = require('./post.service');
// let $: any;
var AppComponent = (function () {
    // 2
    // export class AppComponent implements OnInit {
    // export class AppComponent implements OnInit, OnDestroy {
    // 7
    // isLoading = true;
    // constructor() {
    //   //                         callback #2, throttle service calls
    //   var debounced = _.debounce(function(text: string){
    //     var url = "https://api.spotify.com/v1/search?type=artist&q=" + text;
    //     //             callback #3, ajax call
    //     $.getJSON(url, function(artists: any) {
    //       console.log(artists);
    //     });
    //   }, 400);
    //   //                 callback #1, key-up callback 
    //   $("#search").keyup(function(event: any){
    //     var text: string = event.target.value;
    //     if (text.length < 3) return;
    //     debounced(text);
    //   });
    // }
    function AppComponent(_postSvc) {
        this._postSvc = _postSvc;
        // 1 subscribe via observable
        this._postSvc.getPosts()
            .subscribe(function (posts) { return console.log(posts); });
        // 5 static type checking error
        // this._postSvc.createPost(1); // error on svc & should prevent on client
        // this._postSvc.createPost({ userId: 1, title: "a", body: "b"});
    }
    AppComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            // template: `
            //   <input id="search" type="text" class="form-control" placeholder="Search Spotify">
            // `
            // 7
            template: "\n    <div *ngIf=\"isLoading\">Getting data...</div>\n  "
        }), 
        __metadata('design:paramtypes', [post_service_1.PostService])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.1.js.map