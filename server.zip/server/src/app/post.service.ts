import { Http } from '@angular/http';

// injectable
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

// use interface
import { Post } from './post';

@Injectable()
export class PostService {
    private _url: string = "http://jsonplaceholder.typicode.com/posts"
    constructor(private _http: Http) {}

    // use iterface / type
    getPosts(): Observable<any> {
    // 4
    // getPosts(): Observable<Post[]> {
        return this._http.get(this._url)
            .map((response: any) => response.json());
    }

    // 6
    // createPost(post: any): Observable<any> {
    // use interface / type
    // createPost(post: Post): Observable<any> {
    //     return this._http.post(this._url, JSON.stringify(post))
    //         .map((response: any) => response.json());
    // }

}