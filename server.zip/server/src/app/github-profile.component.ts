import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';

import { Observable } from 'rxjs/Observable';

import { GitHubService } from './github.service';

@Component({
  selector: 'github-profile',
  styles: [`
    .avatar {
      height: 100px;
      width: 100px;
      border-radius: 100%;
    }
  `],
  template: `
    <div *ngIf="isLoading">Getting data...</div>
    <h2>{{ user.login }}</h2>
    <img class="avatar" src="{{ user.avatar_url }}">

    <h3>Followers</h3>
    <div *ngFor="let follower of followers" class="media">
      <div class="mdeia-left">
        <a href="#">
        <img class="media-object avatar" src="{{ follower.avatar_url }}">
        </a>
      </div>
      <div class="media-body">
        <h4 class="media-heading">{{ follower.login }}</h4>
      </div>
    </div>
  `
})
// nested callbacks are complex
export class GithubProfileComponent implements OnInit {
  isLoading = true;
  username = 'octocat';
  user = {};
  followers: string[] = [];

  constructor(private _githubSvc: GitHubService) {}
  
  ngOnInit() {
    this._githubSvc.callGithub(this.username)
      .subscribe(response => {
          this.user = response[0];
          this.followers = response[1];
        },
        null, // error handler here
        () => { this.isLoading = false; } // handler for obs completion
      );
  }
}
