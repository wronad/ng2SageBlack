import { Http } from '@angular/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/forkJoin';

@Injectable()
export class GitHubService {
    private _baseUrl: string = "https://api.github.com/users/";

    constructor(private _http: Http) {}

    getUser(username: string): Observable<any> {
        return this._http.get(this._baseUrl + username)
            .map((response: any) => response.json());
    }

    getFollowers(username: string): Observable<any> {
        return this._http.get(this._baseUrl + username + "/followers")
            .map((response: any) => response.json());
    }

    callGithub(username: string) {
        let observableBatch = [
            this.getUser(username),
            this.getFollowers(username)
        ];
        return Observable.forkJoin(observableBatch);
    }

}