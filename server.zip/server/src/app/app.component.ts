import { Component } from '@angular/core';
import { Http } from '@angular/http';

// 1
import { Observable } from 'rxjs/Observable';

// import svc
import { PostService } from './post.service';

// OnInt lifecyle hook
import { OnInit } from '@angular/core';

// let $: any;

@Component({
  selector: 'my-app',
  // template: `
  //   <input id="search" type="text" class="form-control" placeholder="Search Spotify">
  // `

  // 7
  template: `
    <div *ngIf="isLoading">Getting data...</div>
  `
})
// nested callbacks are complex
export class AppComponent {
// 2
// export class AppComponent implements OnInit {
// export class AppComponent implements OnInit, OnDestroy {

  // 7
  // isLoading = true;

  // constructor() {
  //   //                         callback #2, throttle service calls
  //   var debounced = _.debounce(function(text: string){
  //     var url = "https://api.spotify.com/v1/search?type=artist&q=" + text;
  //     //             callback #3, ajax call
  //     $.getJSON(url, function(artists: any) {
  //       console.log(artists);
  //     });
  //   }, 400);

  //   //                 callback #1, key-up callback 
  //   $("#search").keyup(function(event: any){
  //     var text: string = event.target.value;
  //     if (text.length < 3) return;
  //     debounced(text);
  //   });
  // }
  constructor(private _postSvc: PostService) {
    // 1 subscribe via observable
    this._postSvc.getPosts()
      .subscribe(posts => console.log(posts));

    // 5 static type checking error
    // this._postSvc.createPost(1); // error on svc & should prevent on client
    // this._postSvc.createPost({ userId: 1, title: "a", body: "b"});
  }

  // // 2
  // ngOnInit() {
  //   // subscribe via observable
  //   this._postSvc.getPosts()
  //     // .subscribe(posts => console.log(posts));

  //     // 7 show intellisense
  //     // .subscribe(posts => console.log(posts[0].id));

  //     // 8
  //     .subscribe(posts => {
  //       this.isLoading = false;
  //       console.log(posts[0].id)
  //     });
  // }
}
