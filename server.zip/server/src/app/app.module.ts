import { NgModule }      from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent }  from './app.component';

// // dependency injection
import { PostService } from './post.service';
import { HttpModule } from '@angular/http';

@NgModule({
  imports:      [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
  ],
  declarations: [
    AppComponent,
  ],
  providers: [
    PostService,
  ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
