import { NgModule }      from '@angular/core';

// dynamic
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { BrowserModule } from '@angular/platform-browser';

import { AppComponent }  from './app.component';
import { DynamicFormComponent }  from './dynamic-form.component';

@NgModule({
  imports:      [
    BrowserModule,

    // dynamic
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [
    AppComponent,
    DynamicFormComponent,
  ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
