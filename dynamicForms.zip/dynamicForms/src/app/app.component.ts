import { Component } from '@angular/core';
import { DynamicFormComponent } from './dynamic-form.component';

@Component({
  selector: 'my-app',
  template: '<dynamic-form></dynamic-form>'
})
export class AppComponent  {
}
