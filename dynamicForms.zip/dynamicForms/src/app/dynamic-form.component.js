"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var forms_1 = require('@angular/forms');
// keys from svc
var NM = 'NM';
var VC = 'VC';
var FV = 'FV';
// validation info from svc
var REQ = 'required';
var MIN_LEN = 'minlength';
var NM_MSG = 'Name bust be at least 2 characters!';
var PATTERN = 'pattern';
var NUM_REGEX = '[0-9]?[0-9]';
var NUM_MSG = 'Limits for remaining: 0-99 days!';
var DynamicFormComponent = (function () {
    function DynamicFormComponent() {
        ///////////////////////////////////////////////////////
        // data from svc
        this._nextTrip = 'RVY';
        this._svcDataMap = {
            NM: { value: 'Tyrion', label: 'Name: ', type: 'textbox' },
            VC: { value: 10, label: 'Remaining Vacation Days: ', type: 'number' },
            FV: { value: 'RVY', label: 'Next Destination: ', type: 'dropdown' },
        };
        this._dropDownItems = [
            { value: 'PVR', display: 'Puerto Vallarta' },
            { value: 'RVY', display: 'Revelstoke' },
            { value: 'ENC', display: 'Encinitas' }
        ];
        // data from svc
        ///////////////////////////////////////////////////////
        this._keyLabelMap = {};
        // validation error msg
        this._validationError = '';
        // utilized to turn off submit
        this._formValErrorMap = {};
    }
    // create FormGroup
    // model variable used for 2-way binding for view/template/html
    DynamicFormComponent.prototype.ngOnInit = function () {
        this.buildForm();
    };
    DynamicFormComponent.prototype.buildForm = function () {
        var _this = this;
        var group = {};
        var validators;
        Object.keys(this._svcDataMap).forEach(function (key) {
            validators = [];
            validators.push(forms_1.Validators.required);
            var val = _this._svcDataMap[key].value;
            switch (key) {
                case NM:
                    validators.push(forms_1.Validators.minLength(2));
                    break;
                case VC:
                    validators.push(forms_1.Validators.pattern(NUM_REGEX));
                    break;
                default:
                    break;
            }
            group[key] = new forms_1.FormControl(val, forms_1.Validators.compose(validators));
        });
        this._formGroup = new forms_1.FormGroup(group);
    };
    DynamicFormComponent.prototype.getSvcDataKeys = function () {
        var keys = Object.keys(this._svcDataMap);
        return keys;
    };
    DynamicFormComponent.prototype.checkFormControlErrors = function (key) {
        this._validationError = '';
        var err = false;
        var fc = (this._formGroup.controls[key]);
        if (fc && fc.errors) {
            err = true;
            if (PATTERN in fc.errors) {
                if (fc.errors[PATTERN].requiredPattern.includes(NUM_REGEX)) {
                    this._validationError = NUM_MSG;
                }
            }
            else if (REQ in fc.errors) {
                this._validationError = 'Field is ' + REQ + '!';
            }
            else if (MIN_LEN in fc.errors) {
                this._validationError = NM_MSG;
            }
        }
        if (err) {
            this._formValErrorMap[key] = err;
        }
        else if (key in this._formValErrorMap) {
            delete this._formValErrorMap[key];
        }
        return err;
    };
    DynamicFormComponent.prototype.checkFormErrors = function () {
        var err = false;
        if (Object.keys(this._formValErrorMap).length > 0) {
            err = true;
        }
        return err;
    };
    DynamicFormComponent.prototype.onSubmitClicked = function () {
        console.log(this._formGroup.value);
    };
    DynamicFormComponent.prototype.onClearClicked = function () {
        var _this = this;
        Object.keys(this._svcDataMap).forEach(function (key) {
            if (_this._svcDataMap[key].type == 'textbox') {
                _this._formGroup.controls[key].setValue('');
            }
            else {
                _this._formGroup.controls[key].setValue(0);
            }
        });
    };
    DynamicFormComponent = __decorate([
        core_1.Component({
            selector: 'dynamic-form',
            templateUrl: 'app/dynamic-form.component.html',
        }), 
        __metadata('design:paramtypes', [])
    ], DynamicFormComponent);
    return DynamicFormComponent;
}());
exports.DynamicFormComponent = DynamicFormComponent;
//# sourceMappingURL=dynamic-form.component.js.map