import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';

// keys from svc
const NM: string  = 'NM';
const VC: string = 'VC';
const FV: string = 'FV';

// validation info from svc
const REQ: string = 'required';
const MIN_LEN: string = 'minlength';
const NM_MSG: string = 'Name bust be at least 2 characters!'
const PATTERN: string = 'pattern';
const NUM_REGEX: string = '[0-9]?[0-9]';
const NUM_MSG: string = 'Limits for remaining: 0-99 days!'

@Component({
    selector: 'dynamic-form',
    templateUrl: 'app/dynamic-form.component.html',
})
export class DynamicFormComponent implements OnInit {

    ///////////////////////////////////////////////////////
    // data from svc
    private _nextTrip: string = 'RVY';
    private _svcDataMap: { [id: string]: any } = {
        NM: {value: 'Tyrion', label: 'Name: ',                    type: 'textbox'},
        VC: {value: 10,       label: 'Remaining Vacation Days: ', type: 'number'},
        FV: {value: 'RVY',    label: 'Next Destination: ',        type: 'dropdown'},
    }
    private _dropDownItems: any[] = [
        { value: 'PVR', display: 'Puerto Vallarta' },
        { value: 'RVY', display: 'Revelstoke' },
        { value: 'ENC', display: 'Encinitas' }
    ];
    // data from svc
    ///////////////////////////////////////////////////////

    private _keyLabelMap: { [id: string]: string} = {};
    private _formGroup: FormGroup;

    // validation error msg
    private _validationError: string = '';
    // utilized to turn off submit
    private _formValErrorMap: { [id: string]: boolean } = {};

    // create FormGroup
    // model variable used for 2-way binding for view/template/html
    ngOnInit() {
        this.buildForm();
    }

    private buildForm() {
        let group: any = {};
        let validators: any[];
        
        Object.keys(this._svcDataMap).forEach(key => {
            validators = [];
            validators.push(Validators.required);
            let val: any = this._svcDataMap[key].value;
            switch (key) {
                case NM:
                    validators.push(Validators.minLength(2));
                    break;
                case VC:
                    validators.push(Validators.pattern(NUM_REGEX));
                    break;
                default:
                    break;
            }

            group[key] = new FormControl(val, Validators.compose(validators));
        });

        this._formGroup = new FormGroup(group);
    }

    private getSvcDataKeys(): string[] {
        let keys: string[] = Object.keys(this._svcDataMap);
        return keys;
    }

    private checkFormControlErrors(key: string): Boolean {
        this._validationError = '';
        let err: boolean = false;
        let fc: FormControl = <FormControl>(this._formGroup.controls[key]);
        if (fc && fc.errors) {
            err = true;
            if (PATTERN in fc.errors) {
                if (fc.errors[PATTERN].requiredPattern.includes(NUM_REGEX)) {
                    this._validationError = NUM_MSG;
                }
            } else if (REQ in fc.errors) {
                this._validationError = 'Field is ' + REQ + '!';
            } else if (MIN_LEN in fc.errors) {
                this._validationError = NM_MSG;
            }
        }

        if (err) {
            this._formValErrorMap[key] = err;
        } else if (key in this._formValErrorMap) {
            delete this._formValErrorMap[key];
        }

        return err;
    }

    private checkFormErrors(): boolean {
        let err: boolean = false;
        if (Object.keys(this._formValErrorMap).length > 0) {
            err = true;
        }
        return err;
    }

    private onSubmitClicked() {
        console.log(this._formGroup.value);
    }

    private onClearClicked() {
        Object.keys(this._svcDataMap).forEach(key => {
            if (this._svcDataMap[key].type == 'textbox') {
                this._formGroup.controls[key].setValue('');
            } else {
                this._formGroup.controls[key].setValue(0);
            }
        });
    }
}