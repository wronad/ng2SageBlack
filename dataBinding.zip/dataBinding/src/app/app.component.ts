import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  // 1 bound via interpolation {{ <model property or method> }}
  template: `
  <h1>{{ title }}</h1>
  <img src="{{ imageUrl }}"/>
  <div>
    <button class="btn btn-primary" [hidden]="isHidden">Submit</button>
  </div>
  `

  // // 2 class binding
  // // 3 ng2 terms [<target input>]="<src property/method>"
  // template: `
  // <h1>{{ title }}</h1>
  // <img src="{{ imageUrl }}"/>
  // <div>
  //   <button class="btn btn-primary" [hidden]="isHidden"
  //   [style.backgroundColor]="isActive ? 'yellow' : 'gray'">Submit</button>
  // </div>
  // `

  // // 5 data binding via events
  // template: `
  // <h1>
  //   Preview: {{ title }}
  // </h1>
  // <div><input type="text" [value]="title" (input)="setTitle($event.target.value)"/></div>
  // <img src="{{ imageUrl }}"/>
  // <div>
  //   <button class="btn btn-primary" [hidden]="isHidden"
  //   [style.backgroundColor]="isActive ? 'yellow' : 'gray'"
  //   (click)="clearTitle()">
  //     Clear
  //   </button>
  // </div>
  // `

  // // 6 ngModel directive data binding
  // // [()] [input] & (output) directives combined compactly
  // template: `
  // <h1>
  //   Preview: {{ title }}
  // </h1>
  // <div><input type="text" [(ngModel)]="title"/></div>
  // <img src="{{ imageUrl }}"/>
  // <div>
  //   <button class="btn btn-primary" [hidden]="isHidden"
  //     [style.backgroundColor]="isActive ? 'yellow' : 'gray'"
  //     (click)="clearTitle()">
  //     Clear
  //   </button>
  // </div>
  // `
})
export class AppComponent  {
  title = 'Angular App';
  imageUrl = "http://placehold.it/120x120&text=image1";

  // // 2 class binding
  // isHidden = false;

  // // 3 style binding
  // isActive = true;

  // // 5 data binding via events
  // setTitle(t: string) {
  //   this.title = t;
  // }

  // clearTitle() {
  //   this.title = '';
  // }
}
