import { Component } from '@angular/core';
import { LikeComponent } from './like.component';

@Component({
  selector: 'my-app',
  template: `
  <like [inputTotalLikes]="outputTotalLikes"></like>
  `
})
export class AppComponent  {
  outputTotalLikes:number = 10;
}
