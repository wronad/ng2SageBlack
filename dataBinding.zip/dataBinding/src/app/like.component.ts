import { Component, Input } from '@angular/core';

@Component({
  selector: 'like',
  template: `
  <div>
    Total Likes: {{ inputTotalLikes }}
  </div><div>
    <button class="btn" (click)="yClick()">Yeah</button>
  </div><div>
    <button class="btn" (click)="nClick()">Nope</button>
  </div>
  `
})
export class LikeComponent  {
  // input properties (component input mechanism)
  @Input() inputTotalLikes = 0;

  yClick() {
    this.inputTotalLikes += 1;
  }

  nClick() {
    this.inputTotalLikes -= 1;
  }
}
