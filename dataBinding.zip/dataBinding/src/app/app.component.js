"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var AppComponent = (function () {
    function AppComponent() {
        this.title = 'Angular App';
        this.imageUrl = "http://placehold.it/120x120&text=image1";
        // // 2 class binding
        // isHidden = false;
        // // 3 style binding
        // isActive = true;
        // // 5 data binding via events
        // setTitle(t: string) {
        //   this.title = t;
        // }
        // clearTitle() {
        //   this.title = '';
        // }
    }
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        // 1 bound via interpolation {{ <model property or method> }}
        template: "\n  <h1>{{ title }}</h1>\n  <img src=\"{{ imageUrl }}\"/>\n  <div>\n    <button class=\"btn btn-primary\" [hidden]=\"isHidden\">Submit</button>\n  </div>\n  "
    })
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map