"use strict";
var UsernameValidators = (function () {
    function UsernameValidators() {
    }
    UsernameValidators.noSpace = function (fc) {
        if (fc.value.indexOf(' ') >= 0) {
            return { noSpace: true };
        }
        return null;
    };
    UsernameValidators.mustBeUnique = function (fc) {
        return new Promise(function (resolve, reject) {
            setTimeout(function () {
                if (fc.value == 'irwin')
                    resolve({ mustBeUnique: true });
                else
                    resolve(null);
            }, 2000);
        });
    };
    return UsernameValidators;
}());
exports.UsernameValidators = UsernameValidators;
//# sourceMappingURL=usernameValidators.js.map