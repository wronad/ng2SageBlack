import { Component } from '@angular/core';
// import { FormGroup, FormControl, Validators } from '@angular/forms';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';

import { UsernameValidators } from './usernameValidators';

@Component({
    selector: 'signup-form',
    templateUrl: 'app/signup-form.component.html',
})
export class SignupFormComponent {
    // _formGroup = new FormGroup({
    //     username: new FormControl('', Validators.required),
    //     password: new FormControl('', Validators.required),
    // });

    // _formGroup: FormGroup;

    // constructor(fb: FormBuilder) {
    //     this._formGroup = fb.group({
    //         username: ['', Validators.required],
    //         password: ['', Validators.required]
    //     });
    // }

    // constructor(fb: FormBuilder) {
    //     this._formGroup = fb.group({
    //         username: ['', Validators.compose([
    //             Validators.required,
    //             UsernameValidators.noSpace
    //         ])],
    //         password: ['', Validators.required]
    //     });
    // }

    // constructor(fb: FormBuilder) {
    //     // group(formSate: Object, validator?: ValidatorFn|ValidatorFn[], asyncValidator?: AsyncValidatorFn|AsyncValidatorFn[])
    //     this._formGroup = fb.group({
    //         username: [
    //             '',
    //             Validators.compose([
    //                 Validators.required,
    //                 UsernameValidators.noSpace]),
    //             UsernameValidators.mustBeUnique
    //         ],
    //         password: ['', Validators.required]
    //     });
    // }

    // _invalidLogin: boolean = false;
    // signup() {
    //     // var result = authService.login(this._formGroup.value);
    //     this._invalidLogin = true;
    //     console.log(this._formGroup.value);
    // }
}