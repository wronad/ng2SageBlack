import { FormControl } from '@angular/forms';

export class UsernameValidators {
    static noSpace(fc: FormControl) {
        if (fc.value.indexOf(' ') >= 0) {
            return { noSpace: true };
        }

        return null;
    }

    static mustBeUnique(fc: FormControl) {
        return new Promise((resolve, reject) => {
            setTimeout(function() {
                if (fc.value == 'irwin')
                    resolve({ mustBeUnique: true });
                else
                    resolve(null);
            }, 2000);
        });
    }
}

