import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `
  <div>
    List of Courses
  </div>
  <div>
    No courses yet
  </div>
  `
  // // ngIf adds/removes from DOM
  // // inpsect elements
  // template: `
  // <div *ngIf="courses.length > 0">
  //   List of Courses
  // </div>
  // <div *ngIf="courses.length == 0">
  //   No courses yet
  // </div>
  // `
  // hidden property keeps code in DOM
  // inpsect elements
  // template: `
  // <div [hidden]="courses.length == 0">
  //   List of Courses
  // </div>
  // <div [hidden]="courses.length > 0">
  //   No courses yet
  // </div>
  // `
})
export class AppComponent  {
  courses:string[] = [];
}
