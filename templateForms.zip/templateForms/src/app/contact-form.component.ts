import { Component } from '@angular/core';

@Component({
  selector: 'contact-form',
  templateUrl: 'app/contact-form.component.html'
})
export class ContactFormComponent  {
  _firstName: string = '';
  _comment: string = '';

  log(x: any) {
    console.log(x);
  }
  
  // 4
  onSubmit(form: any) {
    console.log(form);
  }
}
