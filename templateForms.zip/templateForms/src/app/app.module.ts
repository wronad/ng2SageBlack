import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
// 1
import { FormsModule }   from '@angular/forms';

import { AppComponent }  from './app.component';
import { ContactFormComponent }  from './contact-form.component';

@NgModule({
  imports:      [
    BrowserModule,
    FormsModule // 1
  ],
  declarations: [
    AppComponent,
    ContactFormComponent,
  ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
