import { Component } from '@angular/core';

@Component({
    selector: 'subscription-form',
    templateUrl: 'app/subscription-form.component.html'
})
export class SubscriptionFormComponent {
    name = '';
    email = '';
    frequencies = [
        { id: 1, label: 'Daily' }, 
        { id: 2, label: 'Weekly' },
        { id: 3, label: 'Monthly' }
    ];
    selectedFreq = '';
    
    onSubscribe(form: any){
        console.log(form.value);
    }

    setFrequency(val: string) {
        this.selectedFreq = val;
    }
}
