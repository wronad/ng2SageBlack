import { Component } from '@angular/core';

import { CourseService } from './course.service';

// step 1
// decorator similar to annotations in java
@Component({
  selector: 'courses', // identifier to reference in other files
  // html view
  template: '<h2>Courses</h2>',
  // // step 5
  // // bind to model property using interpolation: {{ }}
  // // ng2 updates view for model property changes
  // // 1 way binding: property -> view
  // template: `
  //   <h2>Courses</h2>
  //   {{ title }}
  // `,
  // // step 7
  // // use ng2 directive for loop
  // // directives extend html
  // template: `
  //   <h2>Courses</h2>
  //   {{ title }}
  //   <ul>
  //     <li *ngFor="let course of courses">
  //       {{ course }}
  //     </li>
  //   <ul>
  // `, 
})
// model for html view
// export so other files can import
export class CourseComponent  {
  // // step 4
  // add property
  // title: string = 'The title of courses page';
  // // step 7
  // courses: string[] = ['course1', 'course2', 'course3'];
  // // step 10 utilize service
  // courses: string[] = [];

  // // step 10
  // // utilize dependency injection to refernce service
  // // NOT coupled to service => easier to test
  // constructor(courseService: CourseService) {
  //     // tight coupling - bad
  //     // let cs: CourseService = new CourseService();
  //     // this.courses = cd.getCourses();

  //     this.courses = courseService.getCourses();
  // }
}