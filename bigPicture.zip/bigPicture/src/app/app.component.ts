import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: "<h1>Hello {{name}}</h1>"
  // // step 2
  // // add courses
  // template: `
  //   <h1>Hello {{name}}</h1>
  //   <courses></courses>
  //   ` // back-tick allows definition to span multiple lines
})
export class AppComponent  { name = 'Angular 2'; }
