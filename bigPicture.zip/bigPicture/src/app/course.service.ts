// simple service
// step 9
export class CourseService {
    getCourses(): string[] {
        return ['course1', 'course2', 'course3'];
    }
}