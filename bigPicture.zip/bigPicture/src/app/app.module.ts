import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent }  from './app.component';
// import { CourseComponent }  from './courses.component'; // .ts NOT necessary
// import { CourseService } from './course.service';

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [
    AppComponent,
    // // step 3
    // // add reference so files can access
    // CourseComponent,
  ],
  // // step 12
  // // define for dependency injection
  // providers: [ CourseService ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
